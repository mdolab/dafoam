#!/bin/sh
cd Airfoil
rm -fr 0/* [1-9]* *.txt *.dat *.clr *Log* *000 run*.sh *.info processor* postProcessing
mv constant/polyMesh/points_orig.gz constant/polyMesh/points.gz 
cd ../CompressorFluid
rm -fr 0/* [1-9]* *.txt *.dat *.clr *Log* *000 run*.sh *.info processor* postProcessing
mv constant/polyMesh/points_orig.gz constant/polyMesh/points.gz 
cd ../CompressorSolid
rm -fr 0/* [1-9]* *.txt *.dat *.clr *Log* *000 run*.sh *.info processor* postProcessing
mv constant/polyMesh/points_orig.gz constant/polyMesh/points.gz 
cd ../CurvedCubeHexMesh
rm -fr 0/* [1-9]* *.txt *.dat *.clr *Log* *000 run*.sh *.info processor* postProcessing
mv constant/polyMesh/points_orig.gz constant/polyMesh/points.gz 
cd ../CurvedCubeSnappyHexMesh
rm -fr 0/* [1-9]* *.txt *.dat *.clr *Log* *000 run*.sh *.info processor* postProcessing
mv constant/polyMesh/points_orig.gz constant/polyMesh/points.gz 
cd ../CurvedCubeTriMesh
rm -fr 0/* [1-9]* *.txt *.dat *.clr *Log* *000 run*.sh *.info processor* postProcessing
mv constant/polyMesh/points_orig.gz constant/polyMesh/points.gz 
cd ../UBendDuct
rm -fr 0/* [1-9]* *.txt *.dat *.clr *Log* *000 run*.sh *.info processor* postProcessing
mv constant/polyMesh/points_orig.gz constant/polyMesh/points.gz 
cd ../Wing
rm -fr 0/* [1-9]* *.txt *.dat *.clr *Log* *000 run*.sh *.info processor* postProcessing
mv constant/polyMesh/points_orig.gz constant/polyMesh/points.gz 